import FaqComponent from "../components/FaqComponent"


const FaqPage = () => {
  return (
    <div className="pt-5"><FaqComponent/></div>
  )
}

export default FaqPage